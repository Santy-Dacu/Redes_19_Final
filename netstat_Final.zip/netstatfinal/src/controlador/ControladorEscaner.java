package controlador;

import modelo.Escaner;
import modelo.Equipo;
import modelo.ValidadorIP;

import javax.swing.JProgressBar;
import java.util.List;

public class ControladorEscaner {
    private final Escaner escaner;
    private final ValidadorIP validador;

    public ControladorEscaner() {
        this.escaner = new Escaner();
        this.validador = new ValidadorIP();
    }

    public boolean esIPValida(String ip) {
        return validador.esValida(ip);
    }

    public List<Equipo> escanear(String inicio, String fin, JProgressBar barra) {
        return escaner.escanearRango(inicio, fin, barra);
    }
}
