package controlador;

import modelo.NetstatModelo;

public class ControladorNetstat {
    private final NetstatModelo modelo;

    public ControladorNetstat() {
        this.modelo = new NetstatModelo();
    }

    public String ejecutarNetstat(String modificador) {
        return modelo.ejecutarNetstat(modificador);
    }
}
