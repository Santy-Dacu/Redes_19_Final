package vista;

import controlador.ControladorNetstat;

import javax.swing.*;

public class VentanaNetstat extends JFrame {
    private JButton btnEjecutar;
    private JTextArea areaResultado;
    private JComboBox<String> cmbComando;
    private ControladorNetstat controlador;

    public VentanaNetstat() {
        setTitle("Netstat - Versión Final");
        setSize(700, 500);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(null);
        setLocationRelativeTo(null);

        controlador = new ControladorNetstat();

        JLabel lblComando = new JLabel("Seleccionar comando:");
        lblComando.setBounds(20, 20, 150, 25);
        add(lblComando);

        cmbComando = new JComboBox<>(new String[]{"-a", "-n", "-o"});
        cmbComando.setBounds(170, 20, 80, 25);
        add(cmbComando);

        btnEjecutar = new JButton("Ejecutar Netstat");
        btnEjecutar.setBounds(270, 20, 150, 25);
        add(btnEjecutar);

        areaResultado = new JTextArea();
        areaResultado.setEditable(false);
        JScrollPane scroll = new JScrollPane(areaResultado);
        scroll.setBounds(20, 70, 640, 370);
        add(scroll);

        btnEjecutar.addActionListener(e -> {
            String comando = (String) cmbComando.getSelectedItem();
            String resultado = controlador.ejecutarNetstat(comando);
            areaResultado.setText(resultado);
        });
    }
}
