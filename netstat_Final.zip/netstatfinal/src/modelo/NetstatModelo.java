package modelo;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class NetstatModelo {
    public String ejecutarNetstat(String modificador) {
        StringBuilder salida = new StringBuilder();
        try {
            Process proceso = Runtime.getRuntime().exec("netstat " + modificador);
            BufferedReader lector = new BufferedReader(new InputStreamReader(proceso.getInputStream()));

            String linea;
            while ((linea = lector.readLine()) != null) {
                salida.append(linea).append("\n");
            }
            lector.close();
        } catch (Exception e) {
            salida.append("Error al ejecutar netstat: ").append(e.getMessage());
        }
        return salida.toString();
    }
}
