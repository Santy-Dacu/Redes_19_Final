/**
 * 
 */
/**
 * 
 */
module netstatfinal {
	requires java.desktop;
}